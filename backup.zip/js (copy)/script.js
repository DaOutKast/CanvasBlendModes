window.onload = function () {


    //settings up the generator
    function* gen() {
        console.log("pear");
        console.log("apple");
        console.log("banana");
    }

    //generator returns iterator
    var myGen = gen();
    //play button
    myGen.next();


};


